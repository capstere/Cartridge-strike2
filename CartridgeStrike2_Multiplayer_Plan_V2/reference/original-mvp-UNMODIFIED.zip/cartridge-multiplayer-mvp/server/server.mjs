import { timingSafeEqual } from 'node:crypto';
import { defineServer, defineRoom, Room, ServerError } from 'colyseus';
import {
  EYE_HEIGHT, SPAWNS, readInput, movePlayer, findTarget,
  SHOT_DAMAGE, RESPAWN_MS,
} from './arena-logic.mjs';

const ROOM_CODE = process.env.ROOM_CODE || '';
if (ROOM_CODE.length < 12) throw new Error('ROOM_CODE must be at least 12 characters (keep it in .env, never in GitHub).');
const PORT = Number(process.env.PORT || 2567);
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);

function authorized(provided) {
  if (typeof provided !== 'string' || provided.length > 256) return false;
  const expected = Buffer.from(ROOM_CODE, 'utf8');
  const actual = Buffer.from(provided, 'utf8');
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
function playerName(value, index) {
  if (typeof value !== 'string') return `Operatör-${index}`;
  const cleaned = value.replace(/[^\p{L}\p{N} _-]/gu, '').trim().slice(0, 20);
  return cleaned || `Operatör-${index}`;
}
function facingCenter(x, z) {
  return Math.atan2(x, z);
}
function publicPlayer(p) {
  const { id, name, x, z, yaw, pitch, hp, kills, deaths } = p;
  return { id, name, x, z, yaw, pitch, hp, kills, deaths };
}

class ArenaRoom extends Room {
  maxClients = 10;
  maxMessagesPerSecond = 60;
  players = new Map();
  spawnSerial = 0;

  static onAuth(_token, options, context) {
    const origin = context?.headers?.origin;
    if (origin && ALLOWED_ORIGINS.length && !ALLOWED_ORIGINS.includes(origin)) {
      throw new ServerError(403, 'Otillåten spelklient');
    }
    if (!authorized(options?.code)) throw new ServerError(403, 'Fel rumskod');
    return { admitted: true };
  }

  onCreate() {
    this.onMessage('input', (client, value) => {
      const p = this.players.get(client.sessionId);
      if (p) { p.input = readInput(value); p.lastInputAt = Date.now(); }
    });
    this.onMessage('fire', (client) => this.fire(client));
    // Every 50 ms: authoritative simulation and broadcast snapshots.
    this.setTimestep((deltaMs) => this.tick(deltaMs), 50);
  }

  onJoin(client, options) {
    const slot = this.spawnSerial++;
    const spawn = SPAWNS[slot % SPAWNS.length];
    this.players.set(client.sessionId, {
      id: client.sessionId,
      name: playerName(options?.name, slot + 1),
      x: spawn.x, z: spawn.z,
      yaw: facingCenter(spawn.x, spawn.z), pitch: 0,
      hp: 100, kills: 0, deaths: 0,
      input: readInput({yaw: facingCenter(spawn.x, spawn.z)}),
      nextFireAt: 0,
      lastInputAt: Date.now(),
      deadUntil: 0,
      protectedUntil: Date.now() + 1000,
    });
  }

  onLeave(client) {
    this.players.delete(client.sessionId);
  }

  tick(deltaMs) {
    const now = Date.now();
    for (const p of this.players.values()) {
      if (p.hp <= 0) {
        if (now >= p.deadUntil) {
          const spawn = SPAWNS[this.spawnSerial++ % SPAWNS.length];
          p.x = spawn.x; p.z = spawn.z;
          p.yaw = facingCenter(spawn.x, spawn.z); p.pitch = 0;
          p.hp = 100; p.protectedUntil = now + 1000;
          p.input = readInput({yaw: p.yaw});
          p.lastInputAt = now;
        }
        continue;
      }
      // Stop stale movement if the browser freezes or becomes inactive.
      if (now - p.lastInputAt > 350) { p.input.f = 0; p.input.s = 0; }
      movePlayer(p, deltaMs / 1000);
    }
    this.broadcast('snapshot', { players: [...this.players.values()].map(publicPlayer) });
  }

  fire(client) {
    const attacker = this.players.get(client.sessionId);
    const now = Date.now();
    if (!attacker || attacker.hp <= 0 || now < attacker.nextFireAt) return;
    attacker.nextFireAt = now + 180; // Server-side fire rate.
    const { victim, dir, distance } = findTarget(attacker, this.players.values(), now);
    if (victim) {
      victim.hp = Math.max(0, victim.hp - SHOT_DAMAGE);
      if (victim.hp === 0) {
        victim.deaths++;
        victim.deadUntil = now + RESPAWN_MS;
        attacker.kills++;
        this.broadcast('frag', { attacker: attacker.name, victim: victim.name });
      }
    }
    this.broadcast('shot', {
      from: attacker.id, x: attacker.x, y: EYE_HEIGHT, z: attacker.z,
      dir, distance: Number.isFinite(distance) ? Math.min(distance, 40) : 40,
      hit: victim?.id || null,
    });
  }
}

const server = defineServer({
  rooms: { arena: defineRoom(ArenaRoom) },
  express: (app) => app.get('/health', (_req, res) => res.json({ ok: true })),
});
await server.listen(PORT, '127.0.0.1');
console.log(`Cartridge multiplayer server is listening on 127.0.0.1:${PORT}`);
