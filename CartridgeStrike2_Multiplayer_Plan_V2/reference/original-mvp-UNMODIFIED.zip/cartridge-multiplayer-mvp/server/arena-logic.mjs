// Pure, testable geometry for the Cartridge-Strike2 multiplayer proof of concept.
// The server owns all positions, collisions, damage and respawns.
export const HALF_ARENA = 14;
export const PLAYER_RADIUS = 0.36;
export const EYE_HEIGHT = 1.56;
export const MOVE_SPEED = 4.2;
export const SHOT_RANGE = 40;
export const SHOT_DAMAGE = 34;
export const RESPAWN_MS = 3000;
export const OBSTACLES = Object.freeze([
  { x: 0, z: 0, w: 3.5, d: 3.5 },
  { x: -6, z: 4, w: 2.5, d: 4 },
  { x: 6, z: -4, w: 2.5, d: 4 },
]);
export const SPAWNS = Object.freeze([
  {x:-11,z:-11}, {x:11,z:11}, {x:-11,z:11}, {x:11,z:-11},
  {x:0,z:-11}, {x:0,z:11}, {x:-11,z:0}, {x:11,z:0},
  {x:-7,z:-10}, {x:7,z:10},
]);

const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
function finite(n, otherwise=0) { return typeof n === 'number' && Number.isFinite(n) ? n : otherwise; }

export function readInput(value) {
  const m = value && typeof value === 'object' ? value : {};
  const yaw = finite(m.yaw);
  return {
    f: clamp(finite(m.f), -1, 1),
    s: clamp(finite(m.s), -1, 1),
    yaw: ((yaw + Math.PI) % (Math.PI*2) + Math.PI*2) % (Math.PI*2) - Math.PI,
    pitch: clamp(finite(m.pitch), -1.3, 1.3),
  };
}

export function blocked(x, z, radius=PLAYER_RADIUS) {
  if (Math.abs(x) > HALF_ARENA-radius || Math.abs(z) > HALF_ARENA-radius) return true;
  for (const b of OBSTACLES) {
    const dx = Math.max(Math.abs(x-b.x) - b.w/2, 0);
    const dz = Math.max(Math.abs(z-b.z) - b.d/2, 0);
    if (dx*dx+dz*dz < radius*radius) return true;
  }
  return false;
}

export function movePlayer(player, dt) {
  const i = player.input;
  let x = -Math.sin(i.yaw)*i.f + Math.cos(i.yaw)*i.s;
  let z = -Math.cos(i.yaw)*i.f - Math.sin(i.yaw)*i.s;
  const mag = Math.hypot(x,z);
  if (mag > 1) { x /= mag; z /= mag; }
  const step = MOVE_SPEED * clamp(dt, 0, 0.10);
  const nextX = player.x + x*step, nextZ = player.z + z*step;
  if (!blocked(nextX, player.z)) player.x = nextX;
  if (!blocked(player.x, nextZ)) player.z = nextZ;
  player.yaw = i.yaw;
  player.pitch = i.pitch;
}

export function shotVector(yaw, pitch) {
  const cp = Math.cos(pitch);
  return {x:-Math.sin(yaw)*cp, y:Math.sin(pitch), z:-Math.cos(yaw)*cp};
}

export function sphereDistance(origin, dir, center, radius) {
  const dx=origin.x-center.x, dy=origin.y-center.y, dz=origin.z-center.z;
  const b=2*(dx*dir.x+dy*dir.y+dz*dir.z);
  const c=dx*dx+dy*dy+dz*dz-radius*radius;
  const disc=b*b-4*c;
  if (disc < 0) return Infinity;
  const t=(-b-Math.sqrt(disc))/2;
  return t >= 0 ? t : Infinity;
}

export function boxDistance(origin, dir, b) {
  const min={x:b.x-b.w/2,y:0,z:b.z-b.d/2};
  const max={x:b.x+b.w/2,y:2.6,z:b.z+b.d/2};
  let near=0, far=Infinity;
  for (const axis of ['x','y','z']) {
    if (Math.abs(dir[axis])<1e-10) {
      if(origin[axis]<min[axis]||origin[axis]>max[axis]) return Infinity;
    } else {
      let t1=(min[axis]-origin[axis])/dir[axis];
      let t2=(max[axis]-origin[axis])/dir[axis];
      if (t1>t2) [t1,t2]=[t2,t1];
      near=Math.max(near,t1); far=Math.min(far,t2);
      if (near>far) return Infinity;
    }
  }
  return near;
}

export function findTarget(shooter, players, now=Date.now()) {
  const origin={x:shooter.x,y:EYE_HEIGHT,z:shooter.z};
  const dir=shotVector(shooter.yaw, shooter.pitch);
  let maxDist=SHOT_RANGE;
  for(const box of OBSTACLES) maxDist=Math.min(maxDist,boxDistance(origin,dir,box));
  let victim=null;
  for(const p of players) {
    if(p.id===shooter.id||p.hp<=0||p.protectedUntil>now) continue;
    const t=sphereDistance(origin,dir,{x:p.x,y:1.1,z:p.z},0.7);
    if(t<maxDist) { maxDist=t; victim=p; }
  }
  return {victim,dir,distance:maxDist};
}
