import test from 'node:test';
import assert from 'node:assert/strict';
import {blocked,readInput,movePlayer,findTarget,boxDistance,shotVector,SPAWNS} from '../arena-logic.mjs';

test('inputs validated: no Infinity or out-of-range speed',()=>{
  assert.deepEqual(readInput({f:Infinity,s:999,pitch:-999,yaw:NaN}),{f:0,s:1,yaw:0,pitch:-1.3});
});
test('all spawn points are reachable',()=>{for(const p of SPAWNS) assert.equal(blocked(p.x,p.z),false);});
test('arena boundary and boxes stop movement',()=>{
  assert.equal(blocked(14,0),true);
  assert.equal(blocked(0,0),true);
  const p={x:0,z:-4,input:readInput({f:-1,s:0,yaw:0})};
  for(let i=0;i<40;i++) movePlayer(p,.05);
  assert.ok(p.z < -2.1);
});
test('forward input advances toward negative z',()=>{
  const p={x:-10,z:0,input:readInput({f:1,s:0,yaw:0})};
  movePlayer(p,.1);
  assert.ok(p.z<0);
});
test('firing finds closest visible victim but stops at boxes',()=>{
  const me={id:'a',x:0,z:11,yaw:0,pitch:0,hp:100};
  const near={id:'b',x:0,z:8,hp:100,protectedUntil:0};
  const behind={id:'c',x:0,z:-10,hp:100,protectedUntil:0};
  assert.equal(findTarget(me,[me,near,behind]).victim?.id,'b');
  assert.equal(findTarget(me,[me,behind]).victim,null); // central block
});
test('shot ray handles obstacles and angles',()=>{
  assert.ok(Number.isFinite(boxDistance({x:0,y:1.56,z:11},shotVector(0,0),{x:0,z:0,w:3,d:3})));
  assert.equal(findTarget({id:'a',x:0,z:11,yaw:Math.PI,pitch:0,hp:100},[{id:'b',x:0,z:8,hp:100,protectedUntil:0}]).victim,null);
});
