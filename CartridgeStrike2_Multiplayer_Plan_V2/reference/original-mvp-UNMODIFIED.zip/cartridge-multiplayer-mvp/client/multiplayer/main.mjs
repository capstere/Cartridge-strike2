import * as THREE from 'three';

const $ = (id) => document.getElementById(id);
const view = $('viewport');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#111e2b');
scene.fog = new THREE.Fog('#111e2b', 25, 48);
const camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.05, 90);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.5));
renderer.setSize(innerWidth, innerHeight);
view.append(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xcbe6ff, 0x374559, 2.0));
const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(6, 12, 3);
scene.add(sun);

function block(x, y, z, w, h, d, color) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({color, roughness:.8}));
  mesh.position.set(x, y, z); scene.add(mesh); return mesh;
}
block(0, -0.12, 0, 30, 0.24, 30, '#253b47');
const grid = new THREE.GridHelper(28, 28, 0x405567, 0x344451);
scene.add(grid);
block(0, 1.35, 14, 28.5, 2.7, .25, '#364f60');
block(0, 1.35, -14, 28.5, 2.7, .25, '#364f60');
block(14, 1.35, 0, .25, 2.7, 28.5, '#364f60');
block(-14, 1.35, 0, .25, 2.7, 28.5, '#364f60');
// Geometry must match the server's OBSTACLES array.
block(0, 1.3, 0, 3.5, 2.6, 3.5, '#806b53');
block(-6, 1.3, 4, 2.5, 2.6, 4, '#6e777e');
block(6, 1.3, -4, 2.5, 2.6, 4, '#6e777e');

let room = null, playerSnapshot = null, localYaw = 0, localPitch = 0, receivedSpawn = false;
const keys = new Set(), actors = new Map(), tracers = [];
let lastFrame = performance.now(), flashUntil = 0, messageUntil = 0;
const bodyGeometry = new THREE.BoxGeometry(.65, 1.7, .65);

function playerColor(id) {
  let h=0; for(const letter of id) h=(h*31+letter.charCodeAt(0))>>>0;
  return new THREE.Color().setHSL((h%360)/360, .62, .55);
}
function setStatus(message) { $('status').textContent = message; }
function disconnect(message) {
  room=null; playerSnapshot=null; receivedSpawn = false;
  $('login').hidden=false; $('hud').hidden=true;
  $('connect').disabled=false;
  setStatus(message);
  if (document.pointerLockElement === renderer.domElement) document.exitPointerLock();
}

$('endpoint').value = new URLSearchParams(location.search).get('server') || '';
$('join').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('connect').disabled = true;
  setStatus('Ansluter…');
  try {
    if (!window.Colyseus?.Client) throw new Error('Colyseus SDK kunde inte laddas. Kontrollera anslutningen.');
    const base = new URL($('endpoint').value.trim());
    if (!['https:', 'http:', 'wss:', 'ws:'].includes(base.protocol)) throw new Error('Använd https:// eller wss://');
    const endpoint = base.origin.replace(/^wss:/, 'https:').replace(/^ws:/, 'http:');
    const client = new window.Colyseus.Client(endpoint);
    const joined = await client.joinOrCreate('arena', {
      code: $('code').value,
      name: $('name').value.trim() || 'Operatör',
    });
    room = joined; receivedSpawn = false;
    $('code').value = ''; // Do not keep the secret visible in the DOM.
    $('login').hidden=true; $('hud').hidden=false;
    setStatus('');
    joined.onMessage('snapshot', (message) => updateSnapshot(message));
    joined.onMessage('shot', (message) => showShot(message));
    joined.onMessage('frag', (message) => {
      $('feed').textContent=`${message.attacker} slog ut ${message.victim}`;
      messageUntil=performance.now()+2400;
    });
    joined.onError((_code, message) => setStatus(String(message)));
    joined.onLeave(() => disconnect('Anslutningen bröts. Kontrollera tunneladressen.'));
  } catch (err) {
    setStatus(err?.message || 'Kunde inte ansluta.');
  } finally {
    $('connect').disabled = false;
  }
});

function updateSnapshot(message) {
  if (!room || !Array.isArray(message?.players)) return;
  const seen = new Set();
  playerSnapshot = message.players.find(p=>p.id===room.sessionId) || null;
  if (playerSnapshot && !receivedSpawn) {
    localYaw = playerSnapshot.yaw; localPitch = playerSnapshot.pitch; receivedSpawn = true;
    camera.position.set(playerSnapshot.x, 1.56, playerSnapshot.z);
  }
  const top = [...message.players].sort((a,b)=>b.kills-a.kills).slice(0,10);
  $('score').textContent = top.map(p => `${p.id===room.sessionId?'●':' '} ${p.name.slice(0,14).padEnd(14)} ${p.kills}/${p.deaths}`).join('\n');
  $('health').textContent = playerSnapshot ? `${playerSnapshot.hp} HP` : 'Väntar på servern';
  $('connected').textContent = `${message.players.length}/10 spelare`;
  for(const p of message.players) {
    if (p.id===room.sessionId) continue;
    seen.add(p.id);
    let mesh = actors.get(p.id);
    if(!mesh) {
      mesh=new THREE.Mesh(bodyGeometry,new THREE.MeshStandardMaterial({color:playerColor(p.id)}));
      scene.add(mesh); actors.set(p.id,mesh);
      mesh.position.set(p.x, .85, p.z);
    }
    mesh.userData.target = new THREE.Vector3(p.x, .85, p.z);
    mesh.userData.targetYaw = p.yaw;
    mesh.visible = p.hp > 0;
  }
  for (const [id,mesh] of actors) if(!seen.has(id)) {
    scene.remove(mesh); mesh.material.dispose(); actors.delete(id);
  }
}

function showShot(e) {
  if(!e?.dir) return;
  if(e.from===room?.sessionId && e.hit) flashUntil=performance.now()+170;
  const origin = new THREE.Vector3(e.x, e.y, e.z);
  const end = origin.clone().addScaledVector(new THREE.Vector3(e.dir.x,e.dir.y,e.dir.z), Math.min(e.distance,25));
  const mesh = new THREE.Line(new THREE.BufferGeometry().setFromPoints([origin,end]),new THREE.LineBasicMaterial({color:'#ffd17e',transparent:true,opacity:.85}));
  scene.add(mesh); tracers.push({mesh,until:performance.now()+85});
}

renderer.domElement.addEventListener('click', () => {
  if(room && document.pointerLockElement!==renderer.domElement) renderer.domElement.requestPointerLock();
});
document.addEventListener('mousemove', (e) => {
  if (document.pointerLockElement!==renderer.domElement || !room) return;
  localYaw -= e.movementX*.0025;
  localPitch = Math.min(1.3,Math.max(-1.3,localPitch-e.movementY*.0025));
});
document.addEventListener('keydown', (e) => {
  if (e.target instanceof HTMLInputElement) return;
  keys.add(e.code);
});
document.addEventListener('keyup', (e) => keys.delete(e.code));
document.addEventListener('mousedown', (e) => {
  if (e.button===0 && room && document.pointerLockElement===renderer.domElement) room.send('fire');
});
window.addEventListener('blur', () => keys.clear());

function sendControls() {
  if (!room) return;
  const active = !document.hidden && document.hasFocus();
  room.send('input', {
    f: active ? Number(keys.has('KeyW')||keys.has('ArrowUp'))-Number(keys.has('KeyS')||keys.has('ArrowDown')) : 0,
    s: active ? Number(keys.has('KeyD')||keys.has('ArrowRight'))-Number(keys.has('KeyA')||keys.has('ArrowLeft')) : 0,
    yaw: localYaw,
    pitch: localPitch,
  });
}
setInterval(sendControls, 50);
window.addEventListener('resize', () => {
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
});

function animate(now) {
  requestAnimationFrame(animate);
  const dt=Math.min((now-lastFrame)/1000,.05); lastFrame=now;
  for(const mesh of actors.values()) {
    if (mesh.userData.target) mesh.position.lerp(mesh.userData.target,Math.min(1,dt*12));
    if (typeof mesh.userData.targetYaw==='number') mesh.rotation.y=mesh.userData.targetYaw;
  }
  if(playerSnapshot && playerSnapshot.hp>0) {
    camera.position.lerp(new THREE.Vector3(playerSnapshot.x,1.56,playerSnapshot.z),Math.min(1,dt*18));
  }
  camera.rotation.order='YXZ'; camera.rotation.set(localPitch,localYaw,0);
  for(let i=tracers.length-1;i>=0;i--){
    if(now > tracers[i].until){const {mesh}=tracers.splice(i,1)[0];scene.remove(mesh);mesh.geometry.dispose();mesh.material.dispose();}
  }
  $('hitmarker').hidden = now > flashUntil;
  if (now > messageUntil) $('feed').textContent='';
  renderer.render(scene,camera);
}
requestAnimationFrame(animate);
