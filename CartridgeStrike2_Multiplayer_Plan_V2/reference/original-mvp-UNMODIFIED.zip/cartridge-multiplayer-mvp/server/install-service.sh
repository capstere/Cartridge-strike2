#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -eq 0 ]; then
  echo 'Run as your normal Pi user, not with sudo.' >&2; exit 1
fi
HERE="$(cd "$(dirname "$0")" && pwd)"
NODE="$(command -v node)"
test -f "$HERE/.env" || { echo "Create $HERE/.env first" >&2; exit 1; }
sudo tee /etc/systemd/system/cartridge-colyseus.service >/dev/null <<SERVICE
[Unit]
Description=Cartridge-Strike2 Colyseus multiplayer
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=$(id -un)
Group=$(id -gn)
WorkingDirectory=$HERE
Environment=NODE_ENV=production
EnvironmentFile=$HERE/.env
ExecStart=$NODE $HERE/server.mjs
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=read-only

[Install]
WantedBy=multi-user.target
SERVICE
sudo systemctl daemon-reload
sudo systemctl enable --now cartridge-colyseus.service
sudo systemctl --no-pager --full status cartridge-colyseus.service
