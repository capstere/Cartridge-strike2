# Cartridge-Strike2 · Raspberry Pi 5 + Colyseus multiplayer-test

En separat, körbar **multiplayer-prototyp** för `capstere/Cartridge-strike2`.
Den använder originalprojektets lokalt publicerade **Three.js**, medan Colyseus på Raspberry Pi 5 ansvarar för spelrum, spelarnas positioner, kollisionskontroll, skott, träffar, hälsa och respawn. Den **ersätter inte** den befintliga FPS-motorn, dess botar, banor, karaktärer eller spellägen.

**Kontrollerad 16 november 2026:** Node.js **26 LTS** (Node 20 är EOL), Colyseus `0.18.12`, webbläsar-SDK `@colyseus/sdk@0.18.10`. De sex rena geometri-/logiktesterna körs utan npm-beroenden. Full nätverksdrift, npm-installation och Cloudflare-anslutning behöver testas på din Raspberry Pi.

## 1. Förutsättningar

- Raspberry Pi 5 med **Raspberry Pi OS 64-bit**, internet, åtkomst via SSH/terminal och ett eget nätverk (inte jobbnät).
- En dator för att lägga upp **enbart klientmappen** på GitHub Pages.
- Din nuvarande GitHub Pages-adress: `https://capstere.github.io/Cartridge-strike2/`.
- En nedladdad `cartridge-multiplayer-mvp.zip` på datorn.
- **Ingen egen domän behövs för testet.** Quick Tunnel ger en tillfällig adress som ändras vid omstart.

**Arbeta i två terminalmiljöer:** kommandon under ”Pi” ska köras på Raspberry Pi. Kommandon under ”Dator” körs på datorn där ZIP-filen ligger.

## 2. Pi · installera Node.js 26 LTS

```bash
sudo apt update
sudo apt install -y curl ca-certificates git unzip openssl
curl -fsSL https://deb.nodesource.com/setup_26.x -o /tmp/nodesource_setup.sh
sudo -E bash /tmp/nodesource_setup.sh
sudo apt install -y nodejs
node --version
npm --version
```

Versionen för `node` ska börja på `v26`. Om Pi redan har korrekt Node.js 26 kan du hoppa över installationsblocket.

## 3. Dator → Pi · kopiera ZIP

Från katalogen där filen finns på **din dator**:

```bash
scp cartridge-multiplayer-mvp.zip pi@raspberrypi.local:~/
```

Byt `pi` mot Pi-användarnamnet om det är ett annat. Om `raspberrypi.local` inte hittas, använd Pi:ns lokala IP-adress.

På **Pi**:

```bash
cd ~
unzip -o cartridge-multiplayer-mvp.zip
cd ~/cartridge-multiplayer-mvp/server
```

## 4. Pi · skapa hemlig rumskod och installera Colyseus

Kör i katalogen `~/cartridge-multiplayer-mvp/server`. Följande genererar en slumpmässig kod med 128-bitars entropi. Den ligger bara i `.env` på din Pi.

```bash
cd ~/cartridge-multiplayer-mvp/server
(
  umask 077
  printf 'ROOM_CODE=%s\nPORT=2567\nALLOWED_ORIGINS=https://capstere.github.io,http://localhost:8765\n' "$(openssl rand -hex 16)" > .env
)
chmod 600 .env
npm install --omit=dev
npm test
```

Hämta den hemliga rumskoden när du ska logga in eller skicka den till dina inbjudna medspelare via en privat kanal:

```bash
sed -n 's/^ROOM_CODE=//p' ~/cartridge-multiplayer-mvp/server/.env
```

Lägg **aldrig `.env` eller rumskoden i ett offentligt GitHub-repo eller i spel-URL:en**.

## 5. Pi · starta automatiskt med systemd

```bash
cd ~/cartridge-multiplayer-mvp/server
./install-service.sh
curl -fsS http://127.0.0.1:2567/health
```

Du bör se `{"ok":true}`. Servern lyssnar **bara på `127.0.0.1:2567`**, alltså inte på Pi:ns publika nätverksgränssnitt. Systemd återstartar processen vid fel och efter Pi-omstart.

Vid problem:

```bash
sudo systemctl status cartridge-colyseus --no-pager
sudo journalctl -u cartridge-colyseus -n 80 --no-pager
```

Vid kodändringar på Pi:

```bash
sudo systemctl restart cartridge-colyseus
```

## 6. Pi · installera Cloudflare Tunnel

Kör på Raspberry Pi:

```bash
sudo mkdir -p --mode=0755 /usr/share/keyrings
curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg | sudo tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null
echo 'deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main' | sudo tee /etc/apt/sources.list.d/cloudflared.list
sudo apt update
sudo apt install -y cloudflared
cloudflared --version
```

### Börja med Quick Tunnel (gratis och utan domän)

Kör i **en separat Pi-terminal**, och låt kommandot vara igång medan ni testar:

```bash
cloudflared tunnel --url http://127.0.0.1:2567
```

Cloudflare skriver ut en slumpmässig URL i formatet
`https://valfritt-namn.trycloudflare.com`. **Kopiera din riktiga URL från terminalen.** Ingen port behöver öppnas i routern. Tunneln försvinner när kommandot stoppas och får en ny URL när det startas igen.

Testa i valfri webbläsare:

```
https://DIN-QUICK-TUNNEL.trycloudflare.com/health
```

Du bör se `{"ok":true}`. Fungerar inte det, felsök Pi-tjänsten innan du provar spelet.

## 7. Dator · lägg till den separata klienten i befintligt GitHub-repo

Dessa kommandon körs på en dator där **Git redan är inloggat på ditt GitHub-konto**. Packa först upp ZIP-filen. Publicera bara mappen `client/multiplayer` och ingen serverfil. Exempel:

```bash
unzip cartridge-multiplayer-mvp.zip
git clone https://github.com/capstere/Cartridge-strike2.git
cp -R cartridge-multiplayer-mvp/client/multiplayer Cartridge-strike2/multiplayer
cd Cartridge-strike2
```

**Innan du committar, kontrollera Git-identiteten:**

```bash
git config --get user.name
git config --get user.email
```

Om du vill minska personlig exponering: välj ett neutralt visningsnamn och den **GitHub-provisionerade noreply-adressen** i GitHub-inställningarna. Den kan inte göras om till en godtycklig fejkad adress som ändå ger garanterad anonymitet. Befintliga historiska commits kan fortfarande avslöja tidigare identiteter.

Publicera endast den nya mappen:

```bash
git add multiplayer
git diff --cached --stat
git commit -m "Add isolated multiplayer test arena"
git push
```

När GitHub Pages har publicerats öppnas testarenan här:

`https://capstere.github.io/Cartridge-strike2/multiplayer/`

**Viktigt:** det här ändrar inte `fps/`, spelets ordinarie startsida eller botmotor. GitHub Pages har fortfarande bara statiska webbfiler; den kör **inte** Colyseus-servern.

## 8. Testa två riktiga spelare

1. Öppna `https://capstere.github.io/Cartridge-strike2/multiplayer/` på två datorer eller två olika webbläsare.
2. Fyll i **Quick Tunnel-adressen med `https://`** i Serveradress. SDK:n använder WSS under huven.
3. Fyll i den hemliga rumskoden från `.env` (skicka den privat). Välj ett smeknamn, utan personuppgifter.
4. Tryck **Anslut till testarenan**. Klicka i spelvyn för att låsa musen.
5. Använd WASD för rörelse och vänster musknapp för skott. Observera träffindikator, hälsa, kills/deaths och respawn.

För bekvämlighet kan du dela en klientlänk som bara fyller i serveradressen automatiskt (den innehåller **inte rumskoden**):

```
https://capstere.github.io/Cartridge-strike2/multiplayer/?server=https%3A%2F%2FDIN-TUNNEL.trycloudflare.com
```

Byt `DIN-TUNNEL.trycloudflare.com` till din riktiga tunnelhost. Det är bara ett exempel, inte en existerande URL.

**Obs:** prototypen har en enkel PC-vy utan fulla mobilkontroller, client-side prediction eller lagkompenserad träffregistrering. En Pi 5 med 16 GB räcker normalt gott för det här lilla testet; bandbredd, nätlatens och faktisk last måste mätas innan större lansering.

## 9. Efter test · namngiven tunnel och eventuell befintlig domän

Det nuvarande repot saknar en `CNAME`-fil, men det kan ändå finnas en domän i dina egna konton. **Kontrollera först domänerna i Cloudflare Dashboard** innan du köper en ny.

Om domänen finns i ditt Cloudflare-konto:

1. Cloudflare Dashboard → **Networking → Tunnels** → skapa en tunnel.
2. I tunnelns **Routes** skapar du en **Published application**.
3. Välj hostname, till exempel `spel.dindoman.se`.
4. Service URL: `http://127.0.0.1:2567`.
5. Välj installation för Debian/Linux och kopiera kommandot med *tunnel-token* till **din privata Pi-terminal**. Det ser ut ungefär så här (byt inte in den riktiga token i offentliga dokument):

   ```bash
   sudo cloudflared service install <HEMLIG_TUNNEL_TOKEN>
   ```

6. Kontrollera att Cloudflare-tjänsten körs och att `https://spel.dindoman.se/health` svarar. I klientens Serveradress används `https://spel.dindoman.se`.

Avsluta den tillfälliga Quick Tunnel-processen innan du installerar en permanent service som använder samma `cloudflared`-installation. **En egen domän är valfri för test, men praktisk för en stabil publik serveradress.** Domänpriset beror på din registrator och toppdomän; Cloudflare Tunnel kräver i sig inte att du köper en ny domän.

## 10. Integritet: vad går att dölja?

**Kan skyddas:** Pi:ns externa IPv4-adress exponeras normalt inte direkt för spelarna via Cloudflare Tunnel; du behöver ingen port-forwarding; Colyseus lyssnar endast på loopback; `.env` med rumskoden ligger på Pi; spelarna kan använda pseudonymer.

**Kan fortfarande kopplas till dig:** offentliga GitHub-ägarskap, commit-historik, README/AGENTS-dokumentation, GitHub Pages-hostnamn, domänregistrering/kontouppgifter, Cloudflare-loggar, eventuella webbläsar-/arbetsplatsloggar. Nuvarande `AGENTS.md` innehåller en personlig namnhänvisning. `noindex` förhindrar inte direkt åtkomst. Separera gärna projektet från personliga konton om du vill minska den publika kopplingen, men påstå inte att det gör dig ospårbar.

**Arbetsplats:** fråga IT innan kollegor använder jobbdatorer. Tunneln ska inte användas för att kringgå företagets webbfilter, åtkomstregler eller loggning.

## 11. Vanliga fel

| Symtom | Kontroll |
| --- | --- |
| `curl 127.0.0.1:2567/health` misslyckas | `journalctl -u cartridge-colyseus -n 80` och `node --version`; kontrollera att `npm install` gick igenom |
| `403 Fel rumskod` | Kontrollera `.env` på Pi; ändrad `.env` kräver `sudo systemctl restart cartridge-colyseus` |
| `403 Otillåten spelklient` | Den riktiga HTTPS-sidans origin måste finnas i `ALLOWED_ORIGINS` och tjänsten startas om |
| Klienten öppnas men Three.js laddar inte | Klienten måste ligga under **reporoten** som `multiplayer/` eftersom den importerar `../vendor/three/three.module.js` |
| Tunnel har ny adress | Quick Tunnel byter hostname efter omstart; fyll i den nya adressen |
| 404 på GitHub Pages | Vänta på att Pages publicerat nya committen, kontrollera `multiplayer/index.html` på `main` |
| Tillbakahoppande spelare | Prototypen använder serverstyrd rörelse utan client prediction; det förbättras i nästa version |

## 12. Nästa tekniska steg

När två personer kan gå och skjuta samtidigt i testarenan kopplar vi protokollet till den verkliga `src/fps/game.mjs` och `src/fps/app.mjs`: synkronisera var sin spelare, 5-mot-5-lag, kartans kollisionsdata, vapen, ammo/laddning, objektiv och omgångar. Därefter behövs client prediction, serverreconciliation, interpolering och latenskompensation för att få bra FPS-känsla.

### Filstruktur

```
cartridge-multiplayer-mvp/
  README.md                    Komplett installationsguide
  server/
    server.mjs                Colyseus-rum och auktoritativ simulering
    arena-logic.mjs           Testbar kollisions-/träfflogik
    package.json              Versionslåst Colyseus
    .env.example              Dokumenterade, icke-hemliga variabler
    .gitignore                Skyddar .env mot oavsiktliga commits
    install-service.sh        Skapar systemd-tjänsten
    test/arena.test.mjs       Sex tester
  client/
    multiplayer/
      index.html              Anslutningsformulär och Three.js importmap
      style.css               Separat UI
      main.mjs                Colyseus-klient, kamera, rörelse och skott
```

Teknisk dokumentation: <https://docs.colyseus.io/room>, <https://docs.colyseus.io/auth/room>, <https://developers.cloudflare.com/tunnel/get-started/quick-tunnels/>, <https://developers.cloudflare.com/tunnel/get-started/>.
